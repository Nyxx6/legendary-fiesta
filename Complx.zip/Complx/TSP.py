G = [   [0, 5, 1, 3, 2],
        [5, 0, 2, 1, 1],
        [1, 2, 0, 2, 3],
        [3, 3, 2, 0, 4],
        [2, 1, 3, 4, 0] ]
v = [False] * len(G)
cost = 0
source = 0
h = []
def tsp(P, count):
    global source
    global cost
    
    if count == len(G) and v[source]:
        print("cycle!", h, cost)
        return
    
    for i in range(len(P)):
        if P[i] >= 0 and not v[i]:
            v[i] = True
            h.append(i)
            count += 1
            cost += P[i]
            tsp(G[i], count)
            v[i] = False
            count -= 1
            cost -= P[i]
            h.remove(i)

for k in range(len(G)):
    v = [False] * len(G)
    cost = 0
    tsp(G[k], 0)