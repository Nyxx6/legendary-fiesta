############################ TRACE D'UNE MATRICE ############################
# Create n x n matrix 
matrix = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]
# Size 
n = len(matrix)

# ITERATIVE METHOD
#sum = 0
#for i in range(len(matrix)):
#    sum += matrix[i][i]
#
#print('Trace : ', sum)

# RECURSIVE METHOD
def Trace(matrix, i) :
    if (i == n) :
        return 0
    else :
        return matrix[i][i] + Trace(matrix, i + 1)

#print('Trace : ', Trace(matrix, 0))
############################ MODE D'UN VECTEUR ############################

# Fill Hash table
def Fill(Vect) :
    n = len(V)
    # Create Hash Table to store value -> occurence
    H = {}
    for i in range(n) :
        if Vect[i] in H :
            H[Vect[i]] += 1
        else:
            H[Vect[i]] = 1
    return H

# Get Max Occ from H
def maxO(Tab) :
    m = 0
    i = None
    for j in Tab :
        if Tab[j] > m :
            m = Tab[j]
            i = j
    return i,m

# Create the Vector
V = [2, 3, 6, 5, 4, 3, 4, 6, 4]

i,m = maxO(Fill(V))

print("value : ", i)
print("occurrence : ", m)

def elements_uniques(vecteur):
    elements_set = set(vecteur)
    print(elements_set)
    return len(elements_set) == len(vecteur)

print(elements_uniques([1,2,2,3]))
def compress(chaine):
    compressed = ""
    count = 1

    for i in range(1, len(chaine)):
        if chaine[i] == chaine[i - 1]:
            count += 1
        else:
            compressed += chaine[i - 1] + str(count)
            count = 1
            
    compressed += chaine[-1] + str(count)
    return compressed
print(compress(['a','a','b','a']))