from itertools import permutations

graph = [
    [0, 5, 1, 3, 2], [5, 0, 2, 3, 1], [1, 2, 0, 2, 3], [3, 3, 2, 0, 4], [2, 1, 3, 4, 0] 
    ]

perm = permutations([0,1,2,3,4])


cost = 0
for path in perm:
    j = path[0]
    for i in path:
        cost += graph[j][i]
        j = i
    if 10 > cost + graph[i][path[0]] : 
        print("low cost cycle = ", cost + graph[i][path[0]], path)
    cost = 0

