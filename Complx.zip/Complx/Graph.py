# matrice d'adjacence
matrix = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]
# Size 
n = len(matrix)

# liste chainée

L = {
    '0': ['1', '2', '3'],
    '1': ['4'],
    '2': ['5'],
    '3': ['5', '6', '7'],
    '4': ['8', '11'],
    '5': ['9'],
    '6': [],
    '7': ['6'],
    '8': [],
    '9': ['4'],
    '10': ['12'],
    '11': ['12'],
    '12': [],
    '13': ['14'],
    '14': []
}

def bfs(L, start) :
    file = [start]
    m = []
    m.append(start)

    while file :
        s = file.pop(0)
        print(s)
        for v in L[s] :
            if v not in m :
                file.append(v)
                m.append(v)

def dfs(L, start) :
    pile = [start]
    m = []
    m.append(start)

    while pile :
        s = pile.pop(-1)
        print(s)
        for v in L[s] :
            if v not in m :
                pile.append(v)
                m.append(v)

#dfs(L, '0')

m = []
def rdfs(L, start) :
    if start in m :
        return    
    m.append(start)
    print(start)
    for nb in L[start] :
        if nb not in m :                
            rdfs(nb)
#rdfs('0')

def genDFS() :
    for n in L:
        if n not in m :
            rdfs(n)
#genDFS()

V = [   [0, 5, 1, 3, 2],
        [5, 0, 2, 1, 1],
        [1, 2, 0, 2, 3],
        [3, 3, 2, 0, 4],
        [2, 1, 3, 4, 0]
]

l = len(V)
max = 1000
long = 0
tsp = 0
source = 0
t = 0
#m = {n : False for n in V}
def vdfs(L, start, tsp) :
    global long
    global source
    global max 
    if long > l and start == source :
        print("cyc")
        return  
    if start in m :
        return    
    m.append(start)
    long = long + 1
    for i in range(len(L)) :
        if (L[i] > 0) :
            if i not in m :                 
                #print("from", start, "to", i, "with", L[i], "tsp", tsp + L[i])                 
                vdfs(L, i, tsp + L[i]) 
    m.pop(-1)

for i in range(l) :
    vdfs(V[i], 0, tsp)
i = l - 1 
while(i > 0) :
    vdfs(V[i], 0, tsp)
    i = i - 1


####################

